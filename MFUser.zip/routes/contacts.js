var express = require('express');
var Xvfb = require('xvfb');
var Nightmare = require('nightmare');


var xvfb = new Xvfb({
     silent:true
});

var nightmare = Nightmare({
    typeInterval: 0,
    loadTimeout: 20000, // in ms
    gotoTimeout: 20000, // in ms
    show: false 
});

var router = express.Router();
var fs = require('fs');
var mflogger;

// Kony logger to capture application logs to display using logging service
try {
    mflogger = require(process.env.KONY_LOGIC_LOGGER);
} catch (e) {
    mflogger = console;
}



router.get('/api/v1/getMfLogger', function(req, res, next) {
    console.log(req.body);
    mflogger.info('Request for fetch login time in progress..');
    var response = {};

    // I set this as the overall timer to get total time for transaction.
    var totaltimer = process.hrtime();
    
    xvfb.startSync();
	nightmare
		.goto('https://manage.kony.com')
		.wait('#primary_email')
        .type('input[id="primary_email"]','farzana.shaik@kony.com')
        .type('input[id="password"] ', 'K0ny@123')
        .click('#uid4330')
        .wait('li:nth-child(7)')
		.click('div#main-navbar > div.navbar-inner:nth-child(1) > div.navbar-ex1-collapse.collapse.navbar-collapse.main-navbar-collapse:nth-child(2) > div:nth-child(1) > div.right.clearfix:nth-child(1) > ul.nav.navbar-nav.pull-right.right-navbar-nav:nth-child(1) > li.dropdown:nth-child(2) > a.user-menu:nth-child(1) > span.ng-binding:nth-child(1)')
		.evaluate(function () {        
				return document.querySelector('#main-navbar > div > div.navbar-ex1-collapse.collapse.navbar-collapse.main-navbar-collapse > div > div > ul > li.dropdown.open > a > span').innerText
		})
        .then(function(result) {
            console.log('DONE');
            res.status(200).send(result);
           xvfb.stopSync();
        })
	

     .catch(function (err) {
	    console.log(err);
  })
  })

module.exports = router;